import os
import shutil
from pathlib import Path

def copiar_a_inicio():
    ruta_inicio = os.path.join(os.getenv('APPDATA'), 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup')
    origen = Path(__file__).parent / 'startup.bat'
    destino = os.path.join(ruta_inicio, 'nexor_startup.bat')
    shutil.copyfile(origen, destino)
    print(f'[NEXOR] Script de inicio copiado a: {destino}')

if __name__ == "__main__":
    copiar_a_inicio()
