import os
import sys
import subprocess
import time
import shutil
import platform
from pathlib import Path

def barra_carga(mensaje="Procesando..."):
    print(mensaje)
    for i in range(1, 51):
        time.sleep(0.03)  
        sys.stdout.write(f"\r[{'#'*i}{' '*(50-i)}] {i*2}%")
        sys.stdout.flush()
    print("\n")

def instalar_paquete():
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "."], check=True)
        print("[OK] Nexor instalado correctamente.\n")
    except subprocess.CalledProcessError:
        print("\n[ERROR] Falló la instalación de Nexor.")
        sys.exit(1)

def instalar_inicio():
    barra_carga("Configurando Nexor para iniciar automáticamente...")
    sistema = platform.system()
    origen_carpeta = Path(__file__).parent

    try:
        if sistema == "Windows":
            ruta_inicio = os.path.join(
                os.getenv('APPDATA'),
                'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup'
            )
            origen = origen_carpeta / "nexor.bat"
            destino = os.path.join(ruta_inicio, "nexor_startup.bat")

        elif sistema == "Linux":
            ruta_inicio = Path.home() / ".config" / "autostart"
            ruta_inicio.mkdir(parents=True, exist_ok=True)
            origen = origen_carpeta / "nexor.desktop"
            destino = ruta_inicio / "nexor.desktop"

        elif sistema == "Darwin":  
            ruta_inicio = Path.home() / "Library" / "LaunchAgents"
            ruta_inicio.mkdir(parents=True, exist_ok=True)
            origen = origen_carpeta / "nexor.plist"
            destino = ruta_inicio / "com.nexor.startup.plist"

        else:
            print("[NEXOR] Sistema no soportado.")
            return

        shutil.copyfile(origen, destino)
        print(f"[NEXOR] Script de inicio copiado en: {destino}\n")

    except FileNotFoundError:
        print(f"[NEXOR] No se encontró el archivo de inicio: {origen}")
    except PermissionError:
        print(f"[NEXOR] Permiso denegado. Ejecuta este script con permisos suficientes.")
    except Exception as e:
        print(f"[NEXOR] Error al copiar archivo: {e}")

if __name__ == "__main__":
    barra_carga("Iniciando instalación de Nexor...")
    instalar_paquete()
    instalar_inicio()
    print("¡Nexor está listo para usar!")