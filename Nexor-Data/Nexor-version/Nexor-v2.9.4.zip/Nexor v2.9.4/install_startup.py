import os
import platform
import shutil
from pathlib import Path
import sys
import time

def barra_manual():
    print("Copiando a carpeta de inicio:")
    for i in range(1, 51):
        time.sleep(0.02)
        sys.stdout.write(f"\r[{'#' * i}{' ' * (50 - i)}] {i*2}%")
        sys.stdout.flush()
    print("\n")

def copiar_a_inicio():
    barra_manual()
    sistema = platform.system()
    origen_carpeta = Path(__file__).parent

    if sistema == "Windows":
        ruta_inicio = os.path.join(
            os.getenv('APPDATA'),
            'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup'
        )
        origen = origen_carpeta / "nexor.bat"
        destino = os.path.join(ruta_inicio, "nexor_startup.bat")

    elif sistema == "Linux":
        ruta_inicio = Path.home() / ".config" / "autostart"
        ruta_inicio.mkdir(parents=True, exist_ok=True)
        origen = origen_carpeta / "nexor.desktop"
        destino = ruta_inicio / "nexor.desktop"

    elif sistema == "Darwin":  
        ruta_inicio = Path.home() / "Library" / "LaunchAgents"
        ruta_inicio.mkdir(parents=True, exist_ok=True)
        origen = origen_carpeta / "nexor.plist"
        destino = ruta_inicio / "com.nexor.startup.plist"

    else:
        print("[NEXOR] Sistema no soportado.")
        return

    try:
        shutil.copyfile(origen, destino)
        print(f"[NEXOR] Script de inicio copiado en: {destino}")
    except FileNotFoundError:
        print(f"[NEXOR] No se encontró el archivo de inicio: {origen}")
    except Exception as e:
        print(f"[NEXOR] Error al copiar archivo: {e}")

if __name__ == "__main__":
    copiar_a_inicio()