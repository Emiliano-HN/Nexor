import subprocess
import sys
import time

def barra_carga():
    print("Instalando Nexor...")
    for i in range(1, 51):
        time.sleep(0.05)
        sys.stdout.write(f"\r[{'#'*i}{' '*(50-i)}] {i*2}%")
        sys.stdout.flush()
    print() 

def instalar_paquete():
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "."], check=True)
        print("\n[OK] Nexor instalado correctamente.")
    except subprocess.CalledProcessError:
        print("\n[ERROR] Falló la instalación de Nexor.")
        sys.exit(1)

if __name__ == "__main__":
    barra_carga()
    instalar_paquete()