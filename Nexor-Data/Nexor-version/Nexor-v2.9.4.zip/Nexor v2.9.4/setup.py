from setuptools import setup

setup(
    name='nexor',
    version='2.9.4',
    py_modules=['nexor', 'installnx'], 
    entry_points={
        'console_scripts': [
            'nexor=nexor:main',
            'installnx=installnx:main',    
        ],
    },
    author='Hernández',
    description='Lenguaje de programación Nexor',
)