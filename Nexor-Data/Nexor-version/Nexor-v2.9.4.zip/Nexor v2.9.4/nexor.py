import time
import sys
import re
import ast
import operator as op
import importlib
import json
import os

variables = {}
funciones = {}
funciones_py = {}
modulos_importados = {}
definiendo_funcion = None

ARCHIVO_LIBRERIAS = "nexor_libs.json"

operadores = {
    ast.Add: op.add,
    ast.Sub: op.sub,
    ast.Mult: op.mul,
    ast.Div: op.truediv,
    ast.Pow: op.pow,
    ast.USub: op.neg,
    ast.Mod: op.mod,
    ast.FloorDiv: op.floordiv
}

def crear_archivo_librerias():
    """Crea el archivo de configuración de librerías si no existe"""
    librerias_config = {
        "decimal": {
            "modulo": "decimal",
            "imports": ["Decimal", "getcontext"],
            "configuracion": {
                "precision": 28,
                "auto_convert": True
            },
            "descripcion": "Aritmética decimal de alta precisión"
        },
        "math": {
            "modulo": "math",
            "imports": ["*"],
            "configuracion": {},
            "descripcion": "Funciones matemáticas estándar"
        },
        "datetime": {
            "modulo": "datetime",
            "imports": ["datetime", "date", "time", "timedelta"],
            "configuracion": {},
            "descripcion": "Manejo de fechas y tiempo"
        },
        "random": {
            "modulo": "random",
            "imports": ["*"],
            "configuracion": {},
            "descripcion": "Generación de números aleatorios"
        },
        "json": {
            "modulo": "json",
            "imports": ["loads", "dumps", "load", "dump"],
            "configuracion": {},
            "descripcion": "Procesamiento de JSON"
        },
        "os": {
            "modulo": "os",
            "imports": ["listdir", "getcwd", "chdir", "mkdir", "rmdir", "remove"],
            "configuracion": {},
            "descripcion": "Operaciones del sistema operativo"
        },
        "re": {
            "modulo": "re",
            "imports": ["search", "match", "findall", "sub", "split"],
            "configuracion": {},
            "descripcion": "Expresiones regulares"
        },
        "collections": {
            "modulo": "collections",
            "imports": ["Counter", "defaultdict", "OrderedDict", "deque"],
            "configuracion": {},
            "descripción": "Tipos de datos especializados"
        }
    }
    
    if not os.path.exists(ARCHIVO_LIBRERIAS):
        with open(ARCHIVO_LIBRERIAS, 'w', encoding='utf-8') as f:
            json.dump(librerias_config, f, indent=2, ensure_ascii=False)
        print(f"Archivo de librerías '{ARCHIVO_LIBRERIAS}' creado.")
    
    return librerias_config

def cargar_configuracion_librerias():
    try:
        if os.path.exists(ARCHIVO_LIBRERIAS):
            with open(ARCHIVO_LIBRERIAS, 'r', encoding='utf-8') as f:
                return json.load(f)
        else:
            return crear_archivo_librerias()
    except Exception as e:
        print(f"Error al cargar configuración de librerías: {e}")
        return crear_archivo_librerias()

def importar_libreria(nombre_lib):
    config_libs = cargar_configuracion_librerias()
    
    if nombre_lib not in config_libs:
        print(f"Librería '{nombre_lib}' no encontrada en la configuración.")
        print("Librerías disponibles:")
        for lib in config_libs.keys():
            desc = config_libs[lib].get("descripcion", "Sin descripción")
            print(f"  • {lib}: {desc}")
        return False
    
    try:
        lib_config = config_libs[nombre_lib]
        modulo_nombre = lib_config["modulo"]
        imports = lib_config["imports"]
        configuracion = lib_config.get("configuracion", {})

        modulo = importlib.import_module(modulo_nombre)
        modulos_importados[nombre_lib] = modulo

        if imports == ["*"]:
            for attr in dir(modulo):
                if not attr.startswith("_"):
                    funciones_py[attr] = getattr(modulo, attr)
        else:
            for func_name in imports:
                if hasattr(modulo, func_name):
                    funciones_py[func_name] = getattr(modulo, func_name)

        if nombre_lib == "decimal" and configuracion.get("auto_convert", False):
            if "precision" in configuracion:
                from decimal import getcontext
                getcontext().prec = configuracion["precision"]

            configurar_decimal_automatico()
        
        print(f"Librería '{nombre_lib}' importada exitosamente.")

        funciones_importadas = [f for f in funciones_py.keys() if f in [getattr(modulo, attr) for attr in dir(modulo) if not attr.startswith("_")]]
        if len(funciones_importadas) <= 10:
            print(f"Funciones disponibles: {', '.join([f for f in imports if f != '*'])}")
        else:
            print(f"Se importaron {len(funciones_importadas)} funciones del módulo {modulo_nombre}")
        
        return True
        
    except ImportError as e:
        print(f"Error al importar '{nombre_lib}': {e}")
        print("Asegúrate de que la librería esté instalada en tu sistema.")
        return False
    except Exception as e:
        print(f"Error inesperado al importar '{nombre_lib}': {e}")
        return False

def configurar_decimal_automatico():
    global usar_decimal
    usar_decimal = True

def evaluar(expr):
    global usar_decimal
    try:
        if expr.strip() in variables:
            return variables[expr.strip()]

        if "decimal" in modulos_importados and globals().get("usar_decimal", False):
            return evaluar_con_decimal(expr)
        
        if '"' not in expr:
            for var in variables:
                expr = re.sub(rf'\b{re.escape(var)}\b', str(variables[var]), expr)
        else:
            partes = re.split(r'("[^"]*")', expr)
            for i in range(0, len(partes), 2):
                for var in variables:
                    valor = f'"{variables[var]}"' if isinstance(variables[var], str) else str(variables[var])
                    partes[i] = re.sub(rf'\b{re.escape(var)}\b', valor, partes[i])
            expr = ''.join(partes)
        
        if '"' in expr:
            return eval(expr)
        
        node = ast.parse(expr, mode='eval').body
        return _eval_ast(node)
    except Exception:
        return expr

def evaluar_con_decimal(expr):
    try:
        from decimal import Decimal
        
        if expr.strip() in variables:
            valor = variables[expr.strip()]
            return Decimal(str(valor)) if isinstance(valor, (int, float)) else valor

        expr_procesada = expr
        for var in variables:
            valor = variables[var]
            if isinstance(valor, (int, float)):
                valor_decimal = str(valor)
            else:
                valor_decimal = f'"{valor}"' if isinstance(valor, str) else str(valor)
            expr_procesada = re.sub(rf'\b{re.escape(var)}\b', valor_decimal, expr_procesada)

        def convertir_numeros(match):
            numero = match.group(0)
            if '.' in numero:
                return f'Decimal("{numero}")'
            return numero
        
        expr_procesada = re.sub(r'\b\d+\.\d+\b', convertir_numeros, expr_procesada)

        resultado = eval(expr_procesada, {"Decimal": Decimal, "__builtins__": {}})

        if isinstance(resultado, Decimal):
            return float(resultado)
        
        return resultado
        
    except Exception as e:
        return evaluar_normal(expr)

def evaluar_normal(expr):
    try:
        if '"' not in expr:
            for var in variables:
                expr = re.sub(rf'\b{re.escape(var)}\b', str(variables[var]), expr)
        else:
            partes = re.split(r'("[^"]*")', expr)
            for i in range(0, len(partes), 2):
                for var in variables:
                    valor = f'"{variables[var]}"' if isinstance(variables[var], str) else str(variables[var])
                    partes[i] = re.sub(rf'\b{re.escape(var)}\b', valor, partes[i])
            expr = ''.join(partes)
        
        if '"' in expr:
            return eval(expr)
        
        node = ast.parse(expr, mode='eval').body
        return _eval_ast(node)
    except Exception:
        return expr

def _eval_ast(node):
    if isinstance(node, ast.Num):
        return node.n
    elif isinstance(node, ast.Constant):
        return node.value
    elif isinstance(node, ast.Name):
        return variables.get(node.id, node.id)
    elif isinstance(node, ast.BinOp):
        op_func = operadores.get(type(node.op))
        if not op_func:
            raise TypeError(f"Operador no soportado: {type(node.op)}")
        return op_func(_eval_ast(node.left), _eval_ast(node.right))
    elif isinstance(node, ast.UnaryOp):
        op_func = operadores.get(type(node.op))
        if not op_func:
            raise TypeError(f"Operador no soportado: {type(node.op)}")
        return op_func(_eval_ast(node.operand))
    else:
        raise TypeError(f"Operación no permitida: {ast.dump(node)}")

def mostrar_librerias_disponibles():
    config_libs = cargar_configuracion_librerias()
    
    print("\nLIBRERÍAS DISPONIBLES EN NEXOR")
    print("=" * 50)
    
    for lib_name, lib_info in config_libs.items():
        estado = "IMPORTADA" if lib_name in modulos_importados else "DISPONIBLE"
        print(f"\n {lib_name.upper()} - {estado}")
        print(f"   {lib_info.get('descripcion', 'Sin descripción')}")
        
        if lib_info.get('imports'):
            if lib_info['imports'] == ["*"]:
                print(f"   Importa: Todas las funciones del módulo {lib_info['modulo']}")
            else:
                funciones = ", ".join(lib_info['imports'][:5])
                if len(lib_info['imports']) > 5:
                    funciones += f" ... (+{len(lib_info['imports'])-5} más)"
                print(f"   Funciones: {funciones}")
        
        if lib_info.get('configuracion'):
            print(f"   Configuración especial disponible")
    
    print("\nUso: imp nombre_libreria")
    print("   Ejemplo: imp decimal")

def convertir_temperatura(opcion, numero):
    if opcion == 1:
        resultado = (numero * 1.8) + 32
        conversion = "Celsius a Fahrenheit"
    elif opcion == 2:
        resultado = (numero - 32) / 1.8
        conversion = "Fahrenheit a Celsius"
    elif opcion == 3:
        resultado = numero + 273.15
        conversion = "Celsius a Kelvin"
    elif opcion == 4:
        resultado = numero - 273.15
        conversion = "Kelvin a Celsius"
    elif opcion == 5:
        resultado = (numero - 32) / 1.8 + 273.15
        conversion = "Fahrenheit a Kelvin"
    elif opcion == 6:
        resultado = ((numero - 273.15) * 1.8) + 32
        conversion = "Kelvin a Fahrenheit"
    else:
        print("\n¡Ups! Opción no válida. Por favor selecciona un número del 1 al 7.")
        return None, None

    return resultado, conversion

def mostrar_resultado(resultado, conversion):
    print("\n¡Conversión realizada exitosamente!")
    print(f"El resultado de la conversión {conversion} es: {resultado}")
    time.sleep(1)

def menu_conversiones():
    while True:
        print("\n=== ThermoTool ===")
        print("Selecciona una de las siguientes opciones para convertir temperaturas:")
        print("1. Celsius a Fahrenheit")
        print("2. Fahrenheit a Celsius")
        print("3. Celsius a Kelvin")
        print("4. Kelvin a Celsius")
        print("5. Fahrenheit a Kelvin")
        print("6. Kelvin a Fahrenheit")
        print("7. Salir\n")

        try:
            opcion = int(input("Ingresa el número de la opción deseada (1-7): "))
            if opcion == 7:
                print("\n¡Gracias por usar ThermoTool! ¡Nexor te espera de vuelta!")
                break
            numero = float(input("Ingresa el número a convertir (ejemplo: 25, 100, 300): "))
            resultado, conversion = convertir_temperatura(opcion, numero)

            if resultado is not None:
                mostrar_resultado(resultado, conversion)
        except ValueError:
            print("\n¡Oops! Por favor, ingresa un número válido para la opción y la temperatura.")

def crear_HTML():
    print("\n" + "="*50)
    print("NEXOR - HTMLTool")
    print("Generador de HTML Personalizado")
    print("="*50)
    
    titulo = ""
    encabezado = ""
    parrafos = []
    listas = []
    citas = []
    estilo = ""
    nombre_archivo = "index.html"
    
    while True:
        print("\nMenú de Personalización HTML:")
        print("1. Configurar título del documento")
        print("2. Configurar encabezado principal (H1)")
        print("3. Agregar contenido al cuerpo")
        print("4. Configurar estilo básico")
        print("5. Configurar nombre del archivo")
        print("6. Vista previa del HTML")
        print("7. Generar y guardar archivo HTML")
        print("8. Salir")
        
        try:
            opcion = input("\nSelecciona una opción (1-8): ").strip()
            
            if opcion == "1":
                titulo = input("Ingresa el título del documento: ").strip()
                print(f"Título configurado: '{titulo}'")
                
            elif opcion == "2":
                encabezado = input("Ingresa el encabezado principal: ").strip()
                print(f"Encabezado configurado: '{encabezado}'")
                
            elif opcion == "3":
                submenu_contenido(parrafos, listas, citas)
                
            elif opcion == "4":
                estilo = submenu_estilo()
                
            elif opcion == "5":
                nombre = input("Nombre del archivo (sin extensión): ").strip()
                if nombre:
                    nombre_archivo = f"{nombre}.html"
                print(f"Archivo se guardará como: '{nombre_archivo}'")
                
            elif opcion == "6":
                mostrar_vista_previa(titulo, encabezado, parrafos, listas, citas, estilo)
                
            elif opcion == "7":
                if not titulo and not encabezado and not parrafos:
                    print("Agrega al menos un título, encabezado o párrafo antes de generar.")
                    continue
                    
                html_generado = generar_html(titulo, encabezado, parrafos, listas, citas, estilo)
                
                try:
                    with open(nombre_archivo, "w", encoding="utf-8") as archivo:
                        archivo.write(html_generado)
                    print(f"¡Archivo '{nombre_archivo}' generado exitosamente!")
                    print(f"Ubicación: {nombre_archivo}")
                    break
                except Exception as e:
                    print(f"Error al guardar el archivo: {e}")
                    
            elif opcion == "8":
                print("Saliendo de HTMLTool...")
                break
                
            else:
                print("Opción no válida. Selecciona un número del 1 al 8.")
                
        except KeyboardInterrupt:
            print("\n\nOperación cancelada por el usuario.")
            break
        except Exception as e:
            print(f"Error inesperado: {e}")

def submenu_contenido(parrafos, listas, citas):
    while True:
        print("\nGestión de Contenido:")
        print("1. Agregar párrafo")
        print("2. Agregar lista")
        print("3. Agregar cita/bloque destacado")
        print("4. Ver contenido actual")
        print("5. Volver al menú principal")
        
        opcion = input("\nSelecciona una opción (1-5): ").strip()
        
        if opcion == "1":
            parrafo = input("Escribe el párrafo: ").strip()
            if parrafo:
                parrafos.append(parrafo)
                print("Párrafo agregado.")
                
        elif opcion == "2":
            print("Tipos de lista:")
            print("1. Lista ordenada (numerada)")
            print("2. Lista no ordenada (viñetas)")
            
            tipo_lista = input("Tipo de lista (1-2): ").strip()
            
            if tipo_lista in ["1", "2"]:
                items = []
                print("Ingresa los elementos de la lista (escribe 'fin' para terminar):")
                
                while True:
                    item = input(f"Elemento {len(items) + 1}: ").strip()
                    if item.lower() == 'fin':
                        break
                    if item:
                        items.append(item)
                
                if items:
                    tipo = "ol" if tipo_lista == "1" else "ul"
                    listas.append({"tipo": tipo, "items": items})
                    print("Lista agregada.")
            else:
                print("Tipo de lista no válido.")
                
        elif opcion == "3":
            cita = input("Escribe la cita o texto destacado: ").strip()
            if cita:
                citas.append(cita)
                print("Cita agregada.")
                
        elif opcion == "4":
            print("\nContenido actual:")
            print(f"Párrafos: {len(parrafos)}")
            print(f"Listas: {len(listas)}")
            print(f"Citas: {len(citas)}")
            
        elif opcion == "5":
            break
            
        else:
            print("Opción no válida.")

def submenu_estilo():
    print("\nEstilos Disponibles:")
    print("1. Claro (fondo blanco, texto negro)")
    print("2. Oscuro (fondo negro, texto blanco)")
    print("3. Minimalista (tipografía elegante)")
    print("4. Sin estilo (solo estructura HTML)")
    
    opcion = input("\nSelecciona un estilo (1-4): ").strip()
    
    estilos = {
        "1": "claro",
        "2": "oscuro", 
        "3": "minimalista",
        "4": "sin_estilo"
    }
    
    estilo_seleccionado = estilos.get(opcion, "sin_estilo")
    
    nombres = {
        "claro": "Estilo Claro",
        "oscuro": "Estilo Oscuro",
        "minimalista": "Estilo Minimalista",
        "sin_estilo": "Sin Estilo"
    }
    
    print(f"{nombres[estilo_seleccionado]} seleccionado.")
    return estilo_seleccionado

def mostrar_vista_previa(titulo, encabezado, parrafos, listas, citas, estilo):
    print("\n" + "="*50)
    print("VISTA PREVIA DEL HTML")
    print("="*50)
    
    print(f"Título: {titulo or '(No configurado)'}")
    print(f"Encabezado: {encabezado or '(No configurado)'}")
    print(f"Párrafos: {len(parrafos)}")
    print(f"Listas: {len(listas)}")
    print(f"Citas: {len(citas)}")
    print(f"Estilo: {estilo or 'sin_estilo'}")
    
    if parrafos:
        print("\nPárrafos:")
        for i, p in enumerate(parrafos, 1):
            preview = p[:50] + "..." if len(p) > 50 else p
            print(f"  {i}. {preview}")
    
    print("-" * 50)

def generar_html(titulo, encabezado, parrafos, listas, citas, estilo):
    
    css_estilos = {
        "claro": """
        body { 
            font-family: Arial, sans-serif; 
            background-color: #ffffff; 
            color: #333333; 
            margin: 40px; 
            line-height: 1.6; 
        }
        h1 { color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 10px; }
        blockquote { 
            background: #f8f9fa; 
            border-left: 4px solid #3498db; 
            margin: 20px 0; 
            padding: 15px; 
            font-style: italic; 
        }
        """,
        
        "oscuro": """
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background-color: #1a1a1a; 
            color: #e0e0e0; 
            margin: 40px; 
            line-height: 1.6; 
        }
        h1 { color: #4fc3f7; border-bottom: 2px solid #4fc3f7; padding-bottom: 10px; }
        blockquote { 
            background: #2d2d2d; 
            border-left: 4px solid #4fc3f7; 
            margin: 20px 0; 
            padding: 15px; 
            font-style: italic; 
        }
        ul, ol { color: #b0b0b0; }
        """,
        
        "minimalista": """
        body { 
            font-family: 'Georgia', serif; 
            background-color: #fafafa; 
            color: #2c2c2c; 
            margin: 60px auto; 
            max-width: 800px; 
            line-height: 1.8; 
        }
        h1 { 
            font-weight: 300; 
            color: #333; 
            text-align: center; 
            margin-bottom: 40px; 
            font-size: 2.5em; 
        }
        p { margin-bottom: 20px; text-align: justify; }
        blockquote { 
            background: none; 
            border-left: 3px solid #ccc; 
            margin: 30px 0; 
            padding-left: 20px; 
            font-style: italic; 
            color: #666; 
        }
        """
    }
    
    html = "<!DOCTYPE html>\n<html lang='es'>\n<head>\n"
    html += "    <meta charset='UTF-8'>\n"
    html += "    <meta name='viewport' content='width=device-width, initial-scale=1.0'>\n"
    
    if titulo:
        html += f"    <title>{titulo}</title>\n"
    else:
        html += "    <title>Documento HTML</title>\n"
    
    if estilo != "sin_estilo" and estilo in css_estilos:
        html += "    <style>\n"
        html += css_estilos[estilo]
        html += "    </style>\n"
    
    html += "</head>\n<body>\n"
    
    if encabezado:
        html += f"    <h1>{encabezado}</h1>\n"
    
    for parrafo in parrafos:
        html += f"    <p>{parrafo}</p>\n"
    
    for lista in listas:
        html += f"    <{lista['tipo']}>\n"
        for item in lista['items']:
            html += f"        <li>{item}</li>\n"
        html += f"    </{lista['tipo']}>\n"
    
    for cita in citas:
        html += f"    <blockquote>{cita}</blockquote>\n"
    
    html += "</body>\n</html>"
    
    return html

def ejecutar_bloque(bloque):
    global definiendo_funcion
    
    if not bloque:
        return
    
    i = 0
    while i < len(bloque):
        linea = bloque[i].strip()
        
        if definiendo_funcion and not linea.startswith("fun"):
            funciones[definiendo_funcion]["body"].append(linea)
            if linea.startswith("fun"):
                definiendo_funcion = None
            i += 1
            continue
        
        resultado = ejecutar_linea(linea)
        
        if resultado is not None and isinstance(resultado, tuple):
            tipo, valor = resultado
            
            if tipo == "funcion":
                definiendo_funcion = valor
                
            elif tipo == "fin_funcion":
                definiendo_funcion = None
                
            elif tipo == "condicion":
                sub_bloque = []
                sino_bloque = []
                i += 1
                nivel = 1
                en_sino = False
                
                while i < len(bloque) and nivel > 0:
                    sub_linea = bloque[i].strip()
                    if sub_linea.startswith("dic"):
                        nivel += 1
                    elif sub_linea.startswith("sino") and nivel == 1:
                        en_sino = True
                        i += 1
                        continue
                    elif sub_linea.startswith("nal"):
                        nivel -= 1
                    
                    if nivel > 0:
                        if en_sino:
                            sino_bloque.append(sub_linea)
                        else:
                            sub_bloque.append(sub_linea)
                    i += 1
                
                try:
                    if evaluar(valor):
                        ejecutar_bloque(sub_bloque)
                    elif sino_bloque:
                        ejecutar_bloque(sino_bloque)
                except Exception as e:
                    print(f"Error en condición: {e}")
                
                i -= 1
                
            elif tipo == "bucle":
                sub_bloque = []
                i += 1
                nivel = 1
                
                while i < len(bloque) and nivel > 0:
                    sub_linea = bloque[i].strip()
                    if sub_linea.startswith("rp"):
                        nivel += 1
                    elif sub_linea.startswith("nal"):
                        nivel -= 1
                    
                    if nivel > 0:
                        sub_bloque.append(sub_linea)
                    i += 1
                
                for _ in range(valor):
                    ejecutar_bloque(sub_bloque)
                
                i -= 1
        
        i += 1

def ejecutar_linea(linea):
    global variables, definiendo_funcion, usar_decimal

    if not linea or linea.startswith("#"):
        return

    if linea.startswith("imp "):
        nombre_lib = linea[4:].strip()
        importar_libreria(nombre_lib)
        return

    if linea.startswith("imp "):
        nombre_lib = linea[4:].strip()
        importar_libreria(nombre_lib)
        return

    if linea == "libs":
        mostrar_librerias_disponibles()
        return
    if linea == "thermo":
        menu_conversiones()
        return

    if linea == "html":
        crear_HTML()
        return

    if linea.startswith("fun "):
        partes = linea[4:].split("(")
        if len(partes) >= 2:
            nombre = partes[0].strip()
            parametros_str = partes[1].rstrip(")").strip()
            parametros = [p.strip() for p in parametros_str.split(",") if p.strip()] if parametros_str else []
            
            funciones[nombre] = {
                "parametros": parametros,
                "body": []
            }
            return ("funcion", nombre)

    if linea == "nuf":
        return ("fin_funcion", None)

    if "(" in linea and ")" in linea and not any(op in linea for op in ["+", "-", "*", "/", "=", "<", ">"]):
        partes = linea.split("(")
        if len(partes) >= 2:
            nombre_func = partes[0].strip()

            if nombre_func in funciones_py:
                try:
                    args_str = partes[1].rstrip(")").strip()
                    if args_str:
                        args = [evaluar(arg.strip()) for arg in args_str.split(",")]
                        resultado = funciones_py[nombre_func](*args)
                        print(resultado)
                        return resultado
                    else:
                        resultado = funciones_py[nombre_func]()
                        print(resultado)
                        return resultado
                except Exception as e:
                    print(f"Error al ejecutar función {nombre_func}: {e}")
                    return

            if nombre_func in funciones:
                try:
                    args_str = partes[1].rstrip(")").strip()
                    args = [evaluar(arg.strip()) for arg in args_str.split(",") if arg.strip()] if args_str else []

                    vars_backup = variables.copy()

                    for i, param in enumerate(funciones[nombre_func]["parametros"]):
                        if i < len(args):
                            variables[param] = args[i]

                    ejecutar_bloque(funciones[nombre_func]["body"])

                    variables.clear()
                    variables.update(vars_backup)
                    
                except Exception as e:
                    print(f"Error al ejecutar función {nombre_func}: {e}")
                return

    if linea.startswith("dic "):
        condicion = linea[4:].strip()
        return ("condicion", condicion)

    if linea.startswith("rp "):
        try:
            veces = int(evaluar(linea[3:].strip()))
            return ("bucle", veces)
        except ValueError:
            print("Error: El número de repeticiones debe ser un entero.")
            return

    if linea.startswith("ble "):
        try:
            asignacion = linea[4:].strip()
            if "=" in asignacion:
                nombre, valor = asignacion.split("=", 1)
                nombre = nombre.strip()
                valor = valor.strip()

                valor_evaluado = evaluar(valor)

                if usar_decimal and "decimal" in modulos_importados:
                    try:
                        from decimal import Decimal
                        if isinstance(valor_evaluado, (int, float)):
                            valor_evaluado = Decimal(str(valor_evaluado))
                    except:
                        pass
                
                variables[nombre] = valor_evaluado
                print(f"{nombre} = {valor_evaluado}")
            else:
                print("Error: Formato incorrecto para declaración de variable.")
        except Exception as e:
            print(f"Error en declaración de variable: {e}")
        return

    if linea.startswith("vek "):
        nombre = linea[4:].strip()
        if nombre in variables:
            print(f"{nombre} = {variables[nombre]}")
        else:
            print(f"Variable '{nombre}' no definida.")
        return

    if linea == "vars":
        if variables:
            print("Variables definidas:")
            for nombre, valor in variables.items():
                print(f"  {nombre} = {valor}")
        else:
            print("No hay variables definidas.")
        return

    if linea == "funcs":
        print("Funciones definidas:")
        for nombre, func in funciones.items():
            params = ", ".join(func["parametros"])
            print(f"  {nombre}({params})")
        
        if funciones_py:
            print("Funciones de Python importadas:")
            for nombre in list(funciones_py.keys())[:10]: 
                print(f"  {nombre}()")
            if len(funciones_py) > 10:
                print(f"  ... y {len(funciones_py) - 10} más")
        return

    if linea == "cls":
        os.system('cls' if os.name == 'nt' else 'clear')
        return

    if linea in ["exit", "salir", "quit"]:
        print("¡Hasta la vista, baby!")
        sys.exit(0)

    try:
        resultado = evaluar(linea)
        if resultado != linea: 
            print(resultado)
    except Exception as e:
        print(f"Error: {e}")

def ejecutar_archivo(nombre_archivo):
    """Ejecuta un archivo .nx línea por línea"""
    if not nombre_archivo.endswith('.nx'):
        nombre_archivo += '.nx'
    
    try:
        with open(nombre_archivo, 'r', encoding='utf-8') as archivo:
            lineas = archivo.readlines()
            
        print(f"Ejecutando archivo: {nombre_archivo}")
        print("-" * 40)
        
        for numero_linea, linea in enumerate(lineas, 1):
            linea = linea.strip()
            
            if not linea or linea.startswith("#"):
                continue
            
            print(f"[{numero_linea}] {linea}")
            ejecutar_linea(linea)
            
        print("-" * 40)
        print(f"Archivo {nombre_archivo} ejecutado completamente")
        
    except FileNotFoundError:
        print(f"Error: No se encontró el archivo '{nombre_archivo}'")
    except Exception as e:
        print(f"Error al ejecutar el archivo: {e}")

def main():
    """Función principal del intérprete Nexor"""
    print("Nexor Interpreter v2.9.4")
    print("Escribe 'libs' para ver librerías disponibles")
    print("Escribe 'help' para ver comandos disponibles")
    print("Escribe 'run archivo.nx' para ejecutar un archivo")
    print("Escribe 'exit' para salir\n")

    if len(sys.argv) > 1:
        archivo = sys.argv[1]
        ejecutar_archivo(archivo)
        return
    
    while True:
        try:
            entrada = input("nexor> ").strip()
            
            if entrada == "help":
                mostrar_ayuda()
                continue

            if entrada.startswith("run "):
                archivo = entrada[4:].strip()
                ejecutar_archivo(archivo)
                continue
            
            if entrada:
                ejecutar_linea(entrada)
                
        except KeyboardInterrupt:
            print("\n¡Te espera Nexor!")
            break
        except EOFError:
            print("\n¡Te espera Nexor!")
            break

def mostrar_ayuda():
    """Muestra la ayuda del intérprete"""
    print("""
AYUDA DE NEXOR INTERPRETER

COMANDOS BÁSICOS:
  ble nombre = valor    - Declarar variable
  vek nombre           - Mostrar variable
  vars                 - Mostrar todas las variables
  funcs               - Mostrar funciones disponibles
  cls                 - Limpiar pantalla
  exit/salir/quit     - Salir del intérprete

LIBRERÍAS:
  imp nombre          - Importar librería (ej: imp decimal)
  libs               - Mostrar librerías disponibles

ARCHIVOS:
  run archivo.nx      - Ejecutar archivo Nexor
  
FUNCIONES:
  fun nombre(params)  - Definir función
  nuf                - Fin de función

CONDICIONALES Y BUCLES:
  dic condicion      - Condicional (if)
  sino              - Else
  nal               - Fin de bloque
  rp numero         - Repetir (for)

HERRAMIENTAS:
  thermo            - Conversor de temperatura
  html              - Generador de HTML

EJEMPLOS:
  # Crear archivo ejemplo.nx:
  imp decimal
  ble x = 42
  ble y = 48
  ble z = x + y
  vek z
  
  # Ejecutar desde terminal:
  nexor> run ejemplo.nx
  # O desde línea de comandos:
  python nexor.py ejemplo.nx
""")

if __name__ == "__main__":
    main()