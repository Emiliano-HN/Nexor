from setuptools import setup
import subprocess

subprocess.run(["python", "install_startup.py"], check=True)

setup(
    name='nexor',
    version='2.9.3',
    py_modules=['nexor'],
    entry_points={
        'console_scripts': [
            'nexor=nexor:main',
        ],
    },
    author='Hernández',
    description='Lenguaje de programación Nexor',
)