import time
import sys
import re
import ast
import operator as op
import importlib

variables = {}
funciones = {}
funciones_py = {}
definiendo_funcion = None

operadores = {
    ast.Add: op.add,
    ast.Sub: op.sub,
    ast.Mult: op.mul,
    ast.Div: op.truediv,
    ast.Pow: op.pow,
    ast.USub: op.neg,
    ast.Mod: op.mod,
    ast.FloorDiv: op.floordiv
}

def evaluar(expr):
    try:
        if expr.strip() in variables:
            return variables[expr.strip()]
        
        if '"' not in expr:
            for var in variables:
                expr = re.sub(rf'\b{re.escape(var)}\b', str(variables[var]), expr)
        else:
            partes = re.split(r'("[^"]*")', expr)
            for i in range(0, len(partes), 2):
                for var in variables:
                    valor = f'"{variables[var]}"' if isinstance(variables[var], str) else str(variables[var])
                    partes[i] = re.sub(rf'\b{re.escape(var)}\b', valor, partes[i])
            expr = ''.join(partes)
        
        if '"' in expr:
            return eval(expr)
        
        node = ast.parse(expr, mode='eval').body
        return _eval_ast(node)
    except Exception:
        return expr

def _eval_ast(node):
    if isinstance(node, ast.Num):
        return node.n
    elif isinstance(node, ast.Constant):
        return node.value
    elif isinstance(node, ast.Name):
        return variables.get(node.id, node.id)
    elif isinstance(node, ast.BinOp):
        op_func = operadores.get(type(node.op))
        if not op_func:
            raise TypeError(f"Operador no soportado: {type(node.op)}")
        return op_func(_eval_ast(node.left), _eval_ast(node.right))
    elif isinstance(node, ast.UnaryOp):
        op_func = operadores.get(type(node.op))
        if not op_func:
            raise TypeError(f"Operador no soportado: {type(node.op)}")
        return op_func(_eval_ast(node.operand))
    else:
        raise TypeError(f"Operación no permitida: {ast.dump(node)}")

def convertir_temperatura(opcion, numero):
    if opcion == 1:
        resultado = (numero * 1.8) + 32
        conversion = "Celsius a Fahrenheit"
    elif opcion == 2:
        resultado = (numero - 32) / 1.8
        conversion = "Fahrenheit a Celsius"
    elif opcion == 3:
        resultado = numero + 273.15
        conversion = "Celsius a Kelvin"
    elif opcion == 4:
        resultado = numero - 273.15
        conversion = "Kelvin a Celsius"
    elif opcion == 5:
        resultado = (numero - 32) / 1.8 + 273.15
        conversion = "Fahrenheit a Kelvin"
    elif opcion == 6:
        resultado = ((numero - 273.15) * 1.8) + 32
        conversion = "Kelvin a Fahrenheit"
    else:
        print("\n¡Ups! Opción no válida. Por favor selecciona un número del 1 al 7.")
        return None, None

    return resultado, conversion

def mostrar_resultado(resultado, conversion):
    print("\n¡Conversión realizada exitosamente!")
    print(f"El resultado de la conversión {conversion} es: {resultado}")
    time.sleep(1)

def menu_conversiones():
    """Menú de conversiones de temperatura - ThermoTool"""
    while True:
        print("\n=== ThermoTool ===")
        print("Selecciona una de las siguientes opciones para convertir temperaturas:")
        print("1. Celsius a Fahrenheit")
        print("2. Fahrenheit a Celsius")
        print("3. Celsius a Kelvin")
        print("4. Kelvin a Celsius")
        print("5. Fahrenheit a Kelvin")
        print("6. Kelvin a Fahrenheit")
        print("7. Salir\n")

        try:
            opcion = int(input("Ingresa el número de la opción deseada (1-7): "))
            if opcion == 7:
                print("\n¡Gracias por usar ThermoTool! ¡Nexor te espera de vuelta!")
                break
            numero = float(input("Ingresa el número a convertir (ejemplo: 25, 100, 300): "))
            resultado, conversion = convertir_temperatura(opcion, numero)

            if resultado is not None:
                mostrar_resultado(resultado, conversion)
        except ValueError:
            print("\n¡Oops! Por favor, ingresa un número válido para la opción y la temperatura.")

def crear_HTML():
    """Función para crear archivos HTML desde Nexor - HTMLTool"""
    print("\n" + "="*50)
    print("🌐 NEXOR - HTMLTool")
    print("Generador de HTML Personalizado")
    print("="*50)
    
    titulo = ""
    encabezado = ""
    parrafos = []
    listas = []
    citas = []
    estilo = ""
    nombre_archivo = "index.html"
    
    while True:
        print("\n📋 Menú de Personalización HTML:")
        print("1. Configurar título del documento")
        print("2. Configurar encabezado principal (H1)")
        print("3. Agregar contenido al cuerpo")
        print("4. Configurar estilo básico")
        print("5. Configurar nombre del archivo")
        print("6. Vista previa del HTML")
        print("7. Generar y guardar archivo HTML")
        print("8. Salir")
        
        try:
            opcion = input("\n🔧 Selecciona una opción (1-8): ").strip()
            
            if opcion == "1":
                titulo = input("📝 Ingresa el título del documento: ").strip()
                print(f"✅ Título configurado: '{titulo}'")
                
            elif opcion == "2":
                encabezado = input("📝 Ingresa el encabezado principal: ").strip()
                print(f"✅ Encabezado configurado: '{encabezado}'")
                
            elif opcion == "3":
                submenu_contenido(parrafos, listas, citas)
                
            elif opcion == "4":
                estilo = submenu_estilo()
                
            elif opcion == "5":
                nombre = input("📁 Nombre del archivo (sin extensión): ").strip()
                if nombre:
                    nombre_archivo = f"{nombre}.html"
                print(f"✅ Archivo se guardará como: '{nombre_archivo}'")
                
            elif opcion == "6":
                mostrar_vista_previa(titulo, encabezado, parrafos, listas, citas, estilo)
                
            elif opcion == "7":
                if not titulo and not encabezado and not parrafos:
                    print("⚠️  Agrega al menos un título, encabezado o párrafo antes de generar.")
                    continue
                    
                html_generado = generar_html(titulo, encabezado, parrafos, listas, citas, estilo)
                
                try:
                    with open(nombre_archivo, "w", encoding="utf-8") as archivo:
                        archivo.write(html_generado)
                    print(f"✅ ¡Archivo '{nombre_archivo}' generado exitosamente!")
                    print(f"📍 Ubicación: {nombre_archivo}")
                    break
                except Exception as e:
                    print(f"❌ Error al guardar el archivo: {e}")
                    
            elif opcion == "8":
                print("👋 Saliendo de HTMLTool...")
                break
                
            else:
                print("❌ Opción no válida. Selecciona un número del 1 al 8.")
                
        except KeyboardInterrupt:
            print("\n\n🛑 Operación cancelada por el usuario.")
            break
        except Exception as e:
            print(f"❌ Error inesperado: {e}")

def submenu_contenido(parrafos, listas, citas):
    """Submenú para agregar contenido al cuerpo del HTML"""
    while True:
        print("\n📄 Gestión de Contenido:")
        print("1. Agregar párrafo")
        print("2. Agregar lista")
        print("3. Agregar cita/bloque destacado")
        print("4. Ver contenido actual")
        print("5. Volver al menú principal")
        
        opcion = input("\n🔧 Selecciona una opción (1-5): ").strip()
        
        if opcion == "1":
            parrafo = input("📝 Escribe el párrafo: ").strip()
            if parrafo:
                parrafos.append(parrafo)
                print("✅ Párrafo agregado.")
                
        elif opcion == "2":
            print("📋 Tipos de lista:")
            print("1. Lista ordenada (numerada)")
            print("2. Lista no ordenada (viñetas)")
            
            tipo_lista = input("Tipo de lista (1-2): ").strip()
            
            if tipo_lista in ["1", "2"]:
                items = []
                print("📝 Ingresa los elementos de la lista (escribe 'fin' para terminar):")
                
                while True:
                    item = input(f"Elemento {len(items) + 1}: ").strip()
                    if item.lower() == 'fin':
                        break
                    if item:
                        items.append(item)
                
                if items:
                    tipo = "ol" if tipo_lista == "1" else "ul"
                    listas.append({"tipo": tipo, "items": items})
                    print("✅ Lista agregada.")
            else:
                print("❌ Tipo de lista no válido.")
                
        elif opcion == "3":
            cita = input("📝 Escribe la cita o texto destacado: ").strip()
            if cita:
                citas.append(cita)
                print("✅ Cita agregada.")
                
        elif opcion == "4":
            print("\n📋 Contenido actual:")
            print(f"Párrafos: {len(parrafos)}")
            print(f"Listas: {len(listas)}")
            print(f"Citas: {len(citas)}")
            
        elif opcion == "5":
            break
            
        else:
            print("❌ Opción no válida.")

def submenu_estilo():
    """Submenú para seleccionar el estilo del HTML"""
    print("\n🎨 Estilos Disponibles:")
    print("1. Claro (fondo blanco, texto negro)")
    print("2. Oscuro (fondo negro, texto blanco)")
    print("3. Minimalista (tipografía elegante)")
    print("4. Sin estilo (solo estructura HTML)")
    
    opcion = input("\n🔧 Selecciona un estilo (1-4): ").strip()
    
    estilos = {
        "1": "claro",
        "2": "oscuro", 
        "3": "minimalista",
        "4": "sin_estilo"
    }
    
    estilo_seleccionado = estilos.get(opcion, "sin_estilo")
    
    nombres = {
        "claro": "Estilo Claro",
        "oscuro": "Estilo Oscuro",
        "minimalista": "Estilo Minimalista",
        "sin_estilo": "Sin Estilo"
    }
    
    print(f"✅ {nombres[estilo_seleccionado]} seleccionado.")
    return estilo_seleccionado

def mostrar_vista_previa(titulo, encabezado, parrafos, listas, citas, estilo):
    """Muestra una vista previa del HTML que se generará"""
    print("\n" + "="*50)
    print("👁️  VISTA PREVIA DEL HTML")
    print("="*50)
    
    print(f"📄 Título: {titulo or '(No configurado)'}")
    print(f"📝 Encabezado: {encabezado or '(No configurado)'}")
    print(f"📋 Párrafos: {len(parrafos)}")
    print(f"📃 Listas: {len(listas)}")
    print(f"💬 Citas: {len(citas)}")
    print(f"🎨 Estilo: {estilo or 'sin_estilo'}")
    
    if parrafos:
        print("\n📋 Párrafos:")
        for i, p in enumerate(parrafos, 1):
            preview = p[:50] + "..." if len(p) > 50 else p
            print(f"  {i}. {preview}")
    
    print("-" * 50)

def generar_html(titulo, encabezado, parrafos, listas, citas, estilo):
    """Genera el código HTML completo"""
    
    css_estilos = {
        "claro": """
        body { 
            font-family: Arial, sans-serif; 
            background-color: #ffffff; 
            color: #333333; 
            margin: 40px; 
            line-height: 1.6; 
        }
        h1 { color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 10px; }
        blockquote { 
            background: #f8f9fa; 
            border-left: 4px solid #3498db; 
            margin: 20px 0; 
            padding: 15px; 
            font-style: italic; 
        }
        """,
        
        "oscuro": """
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background-color: #1a1a1a; 
            color: #e0e0e0; 
            margin: 40px; 
            line-height: 1.6; 
        }
        h1 { color: #4fc3f7; border-bottom: 2px solid #4fc3f7; padding-bottom: 10px; }
        blockquote { 
            background: #2d2d2d; 
            border-left: 4px solid #4fc3f7; 
            margin: 20px 0; 
            padding: 15px; 
            font-style: italic; 
        }
        ul, ol { color: #b0b0b0; }
        """,
        
        "minimalista": """
        body { 
            font-family: 'Georgia', serif; 
            background-color: #fafafa; 
            color: #2c2c2c; 
            margin: 60px auto; 
            max-width: 800px; 
            line-height: 1.8; 
        }
        h1 { 
            font-weight: 300; 
            color: #333; 
            text-align: center; 
            margin-bottom: 40px; 
            font-size: 2.5em; 
        }
        p { margin-bottom: 20px; text-align: justify; }
        blockquote { 
            background: none; 
            border-left: 3px solid #ccc; 
            margin: 30px 0; 
            padding-left: 20px; 
            font-style: italic; 
            color: #666; 
        }
        """
    }
    
    html = "<!DOCTYPE html>\n<html lang='es'>\n<head>\n"
    html += "    <meta charset='UTF-8'>\n"
    html += "    <meta name='viewport' content='width=device-width, initial-scale=1.0'>\n"
    
    if titulo:
        html += f"    <title>{titulo}</title>\n"
    else:
        html += "    <title>Documento HTML</title>\n"
    
    if estilo != "sin_estilo" and estilo in css_estilos:
        html += "    <style>\n"
        html += css_estilos[estilo]
        html += "    </style>\n"
    
    html += "</head>\n<body>\n"
    
    if encabezado:
        html += f"    <h1>{encabezado}</h1>\n"
    
    for parrafo in parrafos:
        html += f"    <p>{parrafo}</p>\n"
    
    for lista in listas:
        html += f"    <{lista['tipo']}>\n"
        for item in lista['items']:
            html += f"        <li>{item}</li>\n"
        html += f"    </{lista['tipo']}>\n"
    
    for cita in citas:
        html += f"    <blockquote>{cita}</blockquote>\n"
    
    html += "</body>\n</html>"
    
    return html

def ejecutar_bloque(bloque):
    global definiendo_funcion
    
    if not bloque:
        return
    
    i = 0
    while i < len(bloque):
        linea = bloque[i].strip()
        
        if definiendo_funcion and not linea.startswith("fun"):
            funciones[definiendo_funcion]["body"].append(linea)
            if linea.startswith("fun"):
                definiendo_funcion = None
            i += 1
            continue
        
        resultado = ejecutar_linea(linea)
        
        if resultado is not None and isinstance(resultado, tuple):
            tipo, valor = resultado
            
            if tipo == "funcion":
                definiendo_funcion = valor
                
            elif tipo == "fin_funcion":
                definiendo_funcion = None
                
            elif tipo == "condicion":
                sub_bloque = []
                sino_bloque = []
                i += 1
                nivel = 1
                en_sino = False
                
                while i < len(bloque) and nivel > 0:
                    sub_linea = bloque[i].strip()
                    if sub_linea.startswith("dic"):
                        nivel += 1
                    elif sub_linea.startswith("sino") and nivel == 1:
                        en_sino = True
                        i += 1
                        continue
                    elif sub_linea.startswith("nal"):
                        nivel -= 1
                    
                    if nivel > 0:
                        if en_sino:
                            sino_bloque.append(sub_linea)
                        else:
                            sub_bloque.append(sub_linea)
                    i += 1
                
                try:
                    if evaluar(valor):
                        ejecutar_bloque(sub_bloque)
                    elif sino_bloque:
                        ejecutar_bloque(sino_bloque)
                except Exception as e:
                    print(f"Error en condición: {e}")
                
                i -= 1
                
            elif tipo == "bucle":
                sub_bloque = []
                i += 1
                nivel = 1
                
                while i < len(bloque) and nivel > 0:
                    sub_linea = bloque[i].strip()
                    if sub_linea.startswith("rp"):
                        nivel += 1
                    elif sub_linea.startswith("nal"):
                        nivel -= 1
                    
                    if nivel > 0:
                        sub_bloque.append(sub_linea)
                    i += 1
                
                for _ in range(valor):
                    ejecutar_bloque(sub_bloque)
                
                i -= 1
        
        i += 1

def ejecutar_linea(linea):
    global variables, definiendo_funcion

    if not linea or linea.startswith("@"):
        return

    if linea.startswith("ble"):
        partes = linea.replace("ble", "", 1).split("=", 1)
        if len(partes) < 2:
            return
        nombre = partes[0].strip()
        valor = partes[1].strip()
        if valor == "noc--":
            variables[nombre] = input()
        else:
            variables[nombre] = evaluar(valor)

    elif linea.startswith("vek"):
        contenido = linea[len("vek"):].strip()
        salida = []
        
        tokens = re.findall(r'"[^"]*"|\S+', contenido)
        
        for token in tokens:
            if token.startswith('"') and token.endswith('"'):
                salida.append(token[1:-1])
            else:
                valor_evaluado = evaluar(token.strip())
                salida.append(str(valor_evaluado))
        
        texto = " ".join(salida)
        verde = "\033[92m"
        reset = "\033[0m"
        print(f"{verde}{texto}{reset}")

    elif linea.startswith("dic"):
        condicion = linea.replace("dic", "", 1).replace(":", "").strip()
        return "condicion", condicion

    elif linea.startswith("sino"):
        return "sino"

    elif linea.startswith("nal"):
        return "fin_condicion"

    elif linea.startswith("rp"):
        veces = int(evaluar(linea.replace("rp", "", 1).replace(":", "").strip()))
        return "bucle", veces

    elif linea.startswith("ion "):
        nombre_mod = linea.replace("ion", "", 1).strip()
        try:
            mod = importlib.import_module(nombre_mod)
            for attr in dir(mod):
                if callable(getattr(mod, attr)) and not attr.startswith("__"):
                    funciones_py[attr] = getattr(mod, attr)
        except Exception as e:
            print(f"Error al importar módulo {nombre_mod}: {e}")

    elif linea.startswith("ion"):
        header = linea.replace("ion", "", 1).strip()
        if "(" not in header or not header.endswith("):"):
            print("Error en la definición de la función.")
            return
        nombre, args = header.split("(", 1)
        nombre = nombre.strip()
        args = args.replace("):", "").split(",") if args.replace("):", "").strip() else []
        funciones[nombre] = {"args": [a.strip() for a in args if a.strip()], "body": []}
        return "funcion", nombre

    elif linea.startswith("fun"):
        return "fin_funcion"

    elif "(" in linea and ")" in linea and not linea.startswith(("vek", "ble", "dic", "rp")):
        nombre, args_str = linea.split("(", 1)
        nombre = nombre.strip()
        
        if nombre in funciones or nombre in funciones_py or nombre in ["corex_ThermoTool", "corex_modolibre", "corex_HTMLTool"]:
            args_str = args_str.rstrip(")")
            args = [evaluar(a.strip()) for a in args_str.split(",") if a.strip()] if args_str.strip() else []

            if nombre in funciones:
                funcion = funciones[nombre]
                vars_locales = {}
                for arg_name in funcion["args"]:
                    if arg_name in variables:
                        vars_locales[arg_name] = variables[arg_name]
                
                for i, arg_name in enumerate(funcion["args"]):
                    if i < len(args):
                        variables[arg_name] = args[i]
                
                ejecutar_bloque(funcion["body"])
                
                for arg_name in funcion["args"]:
                    if arg_name in vars_locales:
                        variables[arg_name] = vars_locales[arg_name]
                    else:
                        variables.pop(arg_name, None)

            elif nombre in funciones_py:
                try:
                    funciones_py[nombre](*args)
                except Exception as e:
                    print(f"Error al ejecutar función {nombre}: {e}")

            elif nombre == "corex_ThermoTool":
                menu_conversiones()
            
            elif nombre == "corex_modolibre":
                modo_libre()
            
            elif nombre == "corex_HTMLTool":
                crear_HTML()

def modo_libre():
    print("\n" + "="*50)
    print("🧩 NEXOR - Modo Libre")
    print("="*50)
    print("Escribe comandos Nexor línea por línea.")
    print("Comandos especiales:")
    print("  'salir' o 'exit' - Salir del modo libre")
    print("  'limpiar' o 'clear' - Limpiar variables")
    print("  'variables' - Mostrar todas las variables")
    print("  'funciones' - Mostrar todas las funciones definidas")
    print("  'ayuda' - Mostrar esta ayuda")
    print("-" * 50)
    
    while True:
        try:
            linea = input("nexor>> ").strip()
            
            if linea.lower() in ['salir', 'exit', 'quit']:
                print("¡Nexor modo libre! Saliendo...")
                break
                
            elif linea.lower() in ['limpiar', 'clear']:
                variables.clear()
                funciones.clear()
                funciones_py.clear()
                print("✅ Variables y funciones limpiadas.")
                continue
                
            elif linea.lower() == 'variables':
                if variables:
                    print("📋 Variables actuales:")
                    for var, valor in variables.items():
                        tipo = type(valor).__name__
                        print(f"  {var} = {valor} ({tipo})")
                else:
                    print("📋 No hay variables definidas.")
                continue
                
            elif linea.lower() == 'funciones':
                if funciones:
                    print("🔧 Funciones definidas:")
                    for func, info in funciones.items():
                        args = ", ".join(info["args"]) if info["args"] else ""
                        print(f"  {func}({args}) - {len(info['body'])} líneas")
                else:
                    print("🔧 No hay funciones definidas.")
                if funciones_py:
                    print("📦 Funciones importadas:")
                    for func in funciones_py.keys():
                        print(f"  {func}()")
                continue
                
            elif linea.lower() in ['ayuda', 'help']:
                print("\n📖 Ayuda de Nexor:")
                print("Comandos básicos:")
                print("  ble variable = valor    - Definir variable")
                print("  vek texto variable      - Mostrar texto/variable")
                print("  dic condicion:          - Estructura condicional")
                print("  rp numero:              - Bucle repetir")
                print("  ion funcion(args):      - Definir función")
                print("  fun                     - Fin de función")
                print("Herramientas especiales:")
                print("  corex_ThermoTool()      - Conversor de temperatura")
                print("  corex_HTMLTool()        - Generador de HTML")
                print("  corex_modolibre()       - Modo libre interactivo")
                print("\nEjemplos:")
                print("  ble nombre = \"Nexor\"")
                print("  vek \"Hola\" nombre")
                print("  dic nombre == \"Nexor\":")
                print("    vek \"¡Hola Nexor!\"")
                print("  nal")
                continue
            
            if not linea:
                continue
            
            resultado = ejecutar_linea(linea)
            
            if resultado and isinstance(resultado, tuple):
                tipo, valor = resultado
                
                if tipo == "condicion":
                    print("⚠️  Estructura condicional incompleta. Use 'nal' para cerrar.")
                    bloque_completo = [linea]
                    nivel = 1
                    
                    while nivel > 0:
                        sub_linea = input("... ").strip()
                        bloque_completo.append(sub_linea)
                        
                        if sub_linea.startswith("dic"):
                            nivel += 1
                        elif sub_linea.startswith("nal"):
                            nivel -= 1
                    
                    ejecutar_bloque(bloque_completo)
                    
                elif tipo == "bucle":
                    print("⚠️  Estructura de bucle incompleta. Use 'nal' para cerrar.")
                    bloque_completo = [linea]
                    nivel = 1
                    
                    while nivel > 0:
                        sub_linea = input("... ").strip()
                        bloque_completo.append(sub_linea)
                        
                        if sub_linea.startswith("rp"):
                            nivel += 1
                        elif sub_linea.startswith("nal"):
                            nivel -= 1
                    
                    ejecutar_bloque(bloque_completo)
                    
                elif tipo == "funcion":
                    print(f"⚠️  Definiendo función '{valor}'. Use 'fun' para terminar.")
                    bloque_completo = [linea]
                    
                    while True:
                        sub_linea = input("... ").strip()
                        bloque_completo.append(sub_linea)
                        
                        if sub_linea.startswith("fun"):
                            break
                    
                    ejecutar_bloque(bloque_completo)
                    print(f"✅ Función '{valor}' definida correctamente.")
            
        except KeyboardInterrupt:
            print("\n\n🛑 Interrupción detectada. Use 'salir o exit' para salir limpiamente.")
            continue
        except EOFError:
            print("\n¡Nexor modo libre! Saliendo...")
            break
        except Exception as e:
            print(f"❌ Error: {e}")
            continue

def main():
    if len(sys.argv) != 2:
        print("Uso: nexor archivo.nx")
        return

    ruta = sys.argv[1]

    if not ruta.endswith(".nx"):
        print("Por favor, usa un archivo con extensión .nx")
        return

    try:
        with open(ruta, "r", encoding="utf-8") as archivo:
            lineas = [linea.rstrip("\n") for linea in archivo.readlines()]
    except Exception as e:
        print(f"No se pudo abrir el archivo: {e}")
        return

    ejecutar_bloque(lineas)

if __name__ == "__main__":
    main()