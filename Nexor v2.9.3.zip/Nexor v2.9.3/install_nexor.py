import subprocess
import sys
import time
import threading

def barra_carga(stop_event):
    print("Instalando Nexor...")
    barra = 50
    while not stop_event.is_set():
        for i in range(barra + 1):
            if stop_event.is_set():
                break
            time.sleep(0.05)
            sys.stdout.write("\r[" + "#" * i + " " * (barra - i) + f"] {int(i/barra*100)}%")
            sys.stdout.flush()
    sys.stdout.write("\r[" + "#" * barra + "] 100%\n")
    sys.stdout.flush()

def instalar_paquete():
    stop_event = threading.Event()

    hilo_barra = threading.Thread(target=barra_carga, args=(stop_event,))
    hilo_barra.start()

    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "."],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       check=True)
    except subprocess.CalledProcessError as e:
        stop_event.set()
        print("\nError durante la instalación.")
        sys.exit(1)

    stop_event.set()
    hilo_barra.join()

if __name__ == "__main__":
    instalar_paquete()
