import subprocess
import sys
import time

def barra_carga():
    print("Instalando Nexor...")
    for i in range(1, 51):
        time.sleep(0.05)
        sys.stdout.write("\r[" + "#" * i + " " * (50 - i) + f"] {i*2}%")
        sys.stdout.flush()
    print()

if __name__ == "__main__":
    barra_carga()
    subprocess.run([sys.executable, "-m", "pip", "install", "."], check=True)
