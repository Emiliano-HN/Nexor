import os
import shutil
import sys
import time
from pathlib import Path

def barra_manual():
    print("Copiando a carpeta de inicio:")
    for i in range(1, 51):
        time.sleep(0.02) 
        sys.stdout.write("\r[" + "#" * i + " " * (50 - i) + f"] {i*2}%")
        sys.stdout.flush()
    print("\n")

def copiar_a_inicio():
    barra_manual()

    ruta_inicio = os.path.join(
        os.getenv('APPDATA'),
        'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup'
    )
    origen = Path(__file__).parent / 'startup.bat'
    destino = os.path.join(ruta_inicio, 'nexor_startup.bat')
    shutil.copyfile(origen, destino)
    print(f'[NEXOR] Script de inicio copiado en: {destino}')

if __name__ == "__main__":
    copiar_a_inicio()
