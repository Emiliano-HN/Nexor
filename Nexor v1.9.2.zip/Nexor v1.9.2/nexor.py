import sys
import os
import re
import ast
import operator as op

variables = {}
funciones = {}

def input_simulado():
    return input()

operadores = {
    ast.Add: op.add,
    ast.Sub: op.sub,
    ast.Mult: op.mul,
    ast.Div: op.truediv,
    ast.Pow: op.pow,
    ast.USub: op.neg,
    ast.Mod: op.mod,
    ast.FloorDiv: op.floordiv
}

def evaluar(expr):
    try:
        expr_original = expr
        for var in variables:
            expr = re.sub(rf'\b{var}\b', str(variables[var]), expr)
        print(f"Evaluando: '{expr_original}' → '{expr}'")  # Debug
        node = ast.parse(expr, mode='eval').body
        return _eval_ast(node)
    except Exception:
        return expr

def _eval_ast(node):
    if isinstance(node, ast.Num):  
        return node.n
    elif isinstance(node, ast.Constant):  
        return node.value
    elif isinstance(node, ast.Name): 
        return variables.get(node.id, 0)
    elif isinstance(node, ast.BinOp):  
        return operadores[type(node.op)](_eval_ast(node.left), _eval_ast(node.right))
    elif isinstance(node, ast.UnaryOp): 
        return operadores[type(node.op)](_eval_ast(node.operand))
    else:
        raise TypeError(f"Operación no permitida: {ast.dump(node)}")

def ejecutar_bloque(bloque):
    for linea in bloque:
        ejecutar_linea(linea.strip())

def ejecutar_linea(linea):
    global variables

    if not linea or linea.startswith("@"):
        return

    if linea.startswith("ble"):
        partes = linea.replace("ble", "", 1).split("=", 1)
        if len(partes) < 2:
            return
        nombre = partes[0].strip()
        valor = partes[1].strip()
        if valor == "noc--":
            variables[nombre] = input_simulado()
        else:
            variables[nombre] = evaluar(valor)

    elif linea.startswith("vek"):
        contenido = linea[len("vek"):].strip()
        salida = []
        tokens = re.findall(r'"[^"]*"|[^"]+', contenido)

        for token in tokens:
            if token.startswith('"') and token.endswith('"'):
                salida.append(token[1:-1])
            else:
                try:
                    val = evaluar(token.strip())
                    salida.append(str(val))
                except:
                    salida.append(token.strip())
        print(" ".join(salida))

    elif linea.startswith("dic"):
        condicion = linea.replace("dic", "", 1).replace(":", "").strip()
        return "condicion", condicion

    elif linea.startswith("nal"):
        return "fin_condicion"

    elif linea.startswith("rp"):
        veces = int(evaluar(linea.replace("rp", "", 1).replace(":", "").strip()))
        return "bucle", veces

    elif "(" in linea and ")" in linea:
        nombre, args = linea.split("(", 1)
        args = args.replace(")", "").split(",") if linea.strip().endswith(")") else []
        args = [evaluar(a.strip()) for a in args if a.strip()]
        if nombre in funciones:
            funcion = funciones[nombre]
            local_vars = dict(zip(funcion["args"], args))
            anterior = variables.copy()
            variables.update(local_vars)
            ejecutar_bloque(funcion["body"])
            variables.clear()
            variables.update(anterior)

    elif linea.startswith("ion"):
        header = linea.replace("ion", "", 1).strip()
        nombre, args = header.split("(", 1)
        nombre = nombre.strip()
        args = args.replace("):", "").split(",") if args.strip() else []
        funciones[nombre] = {"args": [a.strip() for a in args if a.strip()], "body": []}
        return "funcion", nombre

    elif linea.startswith("fun"):
        return "fin_funcion"

def main():
    if len(sys.argv) != 2:
        print("Uso: nexor archivo.nx")
        return

    ruta = sys.argv[1]

    if not ruta.endswith(".nx") or not os.path.isfile(ruta):
        print("Archivo no válido o no existe")
        return

    with open(ruta, "r", encoding="utf-8") as archivo:
        lineas = archivo.readlines()

    modo = None
    temp_bloque = []
    condicion_actual = ""
    bucle_veces = 0
    nombre_funcion = ""
    i = 0

    while i < len(lineas):
        linea = lineas[i].rstrip("\n")

        if modo == "funcion":
            if linea.strip().startswith("fun"):
                funciones[nombre_funcion]["body"] = temp_bloque.copy()
                temp_bloque = []
                modo = None
            else:
                temp_bloque.append(linea)
            i += 1
            continue

        elif modo == "condicion":
            if linea.strip().startswith("nal"):
                try:
                    if eval(condicion_actual, variables, variables):
                        ejecutar_bloque(temp_bloque)
                except Exception as e:
                    print(f"Error en condición: {e}")
                temp_bloque = []
                modo = None
            else:
                temp_bloque.append(linea)
            i += 1
            continue

        elif modo == "bucle":
            temp_bloque.append(linea.strip())

            if i + 1 >= len(lineas) or not lineas[i + 1].startswith((" ", "\t")):
                for _ in range(bucle_veces):
                    ejecutar_bloque(temp_bloque)
                temp_bloque = []
                modo = None

            i += 1
            continue

        resultado = ejecutar_linea(linea.strip())

        if resultado:
            if resultado[0] == "funcion":
                modo = "funcion"
                nombre_funcion = resultado[1]
            elif resultado[0] == "condicion":
                modo = "condicion"
                condicion_actual = resultado[1]
                temp_bloque = []
            elif resultado[0] == "bucle":
                modo = "bucle"
                bucle_veces = resultado[1]
                temp_bloque = []

        i += 1

if __name__ == "__main__":
    main()